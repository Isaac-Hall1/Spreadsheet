﻿namespace SS
{
	public class Cell
	{
		public object Content;
		public object Val;

        public Cell(String s)
		{
			Content = s;
			Val = s;
		}
    }
}

