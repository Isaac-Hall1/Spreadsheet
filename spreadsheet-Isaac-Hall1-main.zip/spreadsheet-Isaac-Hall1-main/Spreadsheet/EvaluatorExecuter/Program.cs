﻿using FormulaEvaluator;
namespace Program
{
    public class testEvaluator
    {
        public static void Main(string[] args)
        {
            //Console.WriteLine(Evaluator.Evaluate("y1*3-8/2+4*(8-9*2)/14*x7", getValue));
        }
        static int getValue(String s)
        {
            return 4;
        }
    }
    // 
    // - +
}
